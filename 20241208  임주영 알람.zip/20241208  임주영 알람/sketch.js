let button;
let hours;
let minutes;
let seconds;

let alarms = [];  
let alarmSound;

let message = "";       // 알람 설정 메시지
let messageTimer = 0;   // 메시지가 사라질 시간

function preload() {
  alarmSound = loadSound("alarm.mp3");
}

function setup() {
  createCanvas(400, 400);

  // --- 시간 입력 박스 ---
  hours = createInput();
  hours.size(40);
  hours.position(20, 30);
  styleInput(hours);

  minutes = createInput();
  minutes.size(40);
  minutes.position(100, 30);
  styleInput(minutes);

  seconds = createInput();
  seconds.size(40);
  seconds.position(180, 30);
  styleInput(seconds);

  // --- 버튼 ---
  button = createButton('알람설정!');
  button.position(260, 30);
  button.style("padding", "7px 14px");
  button.style("background", "#4a8cf7");
  button.style("color", "white");
  button.style("border", "none");
  button.style("border-radius", "6px");
  button.style("cursor", "pointer");
  button.style("font-size", "14px");
  button.mousePressed(setTime);
}

function styleInput(inputBox) {
  inputBox.style("padding", "5px");
  inputBox.style("border", "1px solid #ccc");
  inputBox.style("border-radius", "6px");
  inputBox.style("font-size", "14px");
  inputBox.style("text-align", "center");
}

function draw() {
  background(240);

  // 라벨(시/분/초)
  textSize(14);
  fill(50);
  text("시", 20, 25);
  text("분", 100, 25);
  text("초", 180, 25);

  // 현재 시간 표시
  let now = new Date();
  let h = nf(now.getHours(), 2);
  let m = nf(now.getMinutes(), 2);
  let s = nf(now.getSeconds(), 2);

  textSize(18);
  text(`현재시간: ${h}:${m}:${s}`, 20, 100);

  // 알람 체크
  checkAlarms();

  // 메시지 표시
  if (millis() < messageTimer) {
    fill(0, 150, 0);
    textSize(18);
    text(message, 20, 140);
  }
}

function setTime() {
  let h = nf(int(hours.value()), 2);
  let m = nf(int(minutes.value()), 2);
  let s = nf(int(seconds.value()), 2);

  alarms.push({ h, m, s });

  console.log("알람 등록:", h, m, s);

  // 메시지 띄우기
  message = `알람 설정 완료! (${h}:${m}:${s})`;
  messageTimer = millis() + 2500; // 2.5초 동안 표시
}

function checkAlarms() {
  let now = new Date();
  let h = nf(now.getHours(), 2);
  let m = nf(now.getMinutes(), 2);
  let s = nf(now.getSeconds(), 2);

  for (let i = 0; i < alarms.length; i++) {
    let a = alarms[i];

    if (a.h === h && a.m === m && a.s === s) {
      if (!alarmSound.isPlaying()) {
        alarmSound.play();
      }
    }
  }
}
